# AISaid Vercel API Project

This repository contains serverless API endpoints used for the AISaid Chrome extension.

## Endpoints

- `api/proxyapi.js` – Secure proxy to OpenAI API
- `api/stripecheckout.js` – Creates Stripe Checkout session
- `api/StripeWebhook.js` – Stripe webhook handler

## Deployment

1. Upload this folder as a new project on Vercel.
2. Set these environment variables in Vercel:
   - `OPENAI_API_KEY`
   - `STRIPE_SECRET_KEY`
   - `STRIPE_PRICE_ID`
   - `BASE_URL`

3. Deploy and copy the endpoint URLs for your Chrome extension.

Enjoy using AISaid securely and efficiently!
